const { ethers, upgrades } = require("hardhat");
const hre = require("hardhat");

async function main() {

  signers = await ethers.getSigners();
  user = signers[0];
  // admin = signers[1];


  BRIDGE = await ethers.getContractFactory("Bridge6")
  bridge = await BRIDGE.attach("0xE38c73a0A651Ca30501a75eD9423E74da6E03E36")
  console.log(await bridge.owner(), user.address)
  // const gas = await bridge.listToken(["0x7F04E01b380ee5e2f048eB081D1C775593e97447", 97], ["0x840fCF99dE21c08f8e808af7595A81875dDAaFb6", 11155111], false, {value: 850000000000000})

  // console.log(gas);
  // const data = ""
  // await bridge.listToken(["0x9A36F58E71762a23d4903C6eA18C501a04feB1e5", 11155111],["0x52e949e035eb85f5Bcb934B8ceb620103eAa5d96", 97], "false", {value: 850000000000000})
  // // await bridge.deployToken(1, data, "0xb11Da2d03060Ab14e32B8b1208Be5492646340e3", user.address)
  console.log(await bridge.chainSupported(97))


  //   await bridge.unlock(user.address, "0x04D77Ae999e479D44AcF18b3797D3A5F31B7f785", "0x0000000000000000000000000000000000000000", 90000000000000000000n, 10000000000000000000n, 0, false, 11155111, 97, signature.r, signature.s, signature.v, {value: 0})



}

main()